package com.example.logintest;

public class Trip {

    String trip_id, start, end, money, people_count, join_people_count, datetime;

    public String getTrip_id() {
        return trip_id;
    }

    public String getStart() {
        return start;
    }

    public String getEnd() {
        return end;
    }

    public String getMoney() {
        return money;
    }

    public String getPeople_count() {
        return people_count;
    }

    public String getJoin_people_count() {
        return join_people_count;
    }

    public String getDatetime() {
        return datetime;
    }


}
