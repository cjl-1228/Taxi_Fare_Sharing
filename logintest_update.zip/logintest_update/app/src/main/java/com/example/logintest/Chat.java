package com.example.logintest;

public class Chat {

    String fullname, message, datetime;

    public String getFullname() {
        return fullname;
    }

    public String getMessage() {
        return message;
    }

    public String getDatetime() {
        return datetime;
    }
}
