package com.example.logintest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class chatpage extends AppCompatActivity {

    TextView txv, back, send,output, txv2;
    EditText message;
    String data="";
    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://loginregister-92b48-default-rtdb.firebaseio.com/");

    RecyclerView recyclerView;
    MyAdapter2 myAdapter;
    ArrayList<Chat> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatpage);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        Intent it = getIntent();
        String account = it.getStringExtra("帳號");
        String fullname = it.getStringExtra("名稱");
        String id = it.getStringExtra("車次");

        txv = findViewById(R.id.txv);
        back = findViewById(R.id.back);
        send = findViewById(R.id.send);
        message = findViewById(R.id.message);
        output = findViewById(R.id.output);
        txv2 = findViewById(R.id.txv2);

        txv.setText(id+"備忘錄");


        txv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                recyclerView = findViewById(R.id.chatList);
                recyclerView.setHasFixedSize(true);
                recyclerView.setLayoutManager(new LinearLayoutManager(myAdapter.context));

                list = new ArrayList<>();
                myAdapter = new MyAdapter2(myAdapter.context,list);
                recyclerView.setAdapter(myAdapter);

                databaseReference.child("chat").child(id).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for(DataSnapshot dataSnapshot : snapshot.getChildren()){

                            Chat chat= dataSnapshot.getValue(Chat.class);
                            list.add(chat);
                        }
                        myAdapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });


        recyclerView = findViewById(R.id.chatList);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        list = new ArrayList<>();
        myAdapter = new MyAdapter2(this,list);
        recyclerView.setAdapter(myAdapter);

        databaseReference.child("chat").child(id).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot : snapshot.getChildren()){

                    Chat chat= dataSnapshot.getValue(Chat.class);
                    list.add(chat);
                }
                myAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });




        databaseReference.child("chat").child(id).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String ma = snapshot.getValue().toString();
                data+=ma;
                output.setText(data);





            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });






        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String messageTxt = message.getText().toString();
                if(messageTxt.equals("")){
                    Toast.makeText(chatpage.this, "請輸入訊息!", Toast.LENGTH_LONG).show();
                }
                else{
                    long date = System.currentTimeMillis();
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddahh:mm:ss");

                    String dateString = sdf.format(date);

                    databaseReference.child("chat").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            databaseReference.child("chat").child(id).child(fullname+"_"+messageTxt+"_"+dateString).child("fullname").setValue(fullname);
                            databaseReference.child("chat").child(id).child(fullname+"_"+messageTxt+"_"+dateString).child("message").setValue(messageTxt);
                            databaseReference.child("chat").child(id).child(fullname+"_"+messageTxt+"_"+dateString).child("datetime").setValue(dateString);
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                    message.setText("");
                    Toast.makeText(chatpage.this, "已新增訊息至備忘錄!", Toast.LENGTH_LONG).show();




                }
            }
        });



        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(chatpage.this, MainActivity.class);
                it.putExtra("帳號",account);
                it.putExtra("名稱",fullname);

                startActivity(it);
                finish();
            }
        });

    }
}